<!doctype html>
<html lang="en">

<head>

	<title>PHP MySQL </title>
	
		
</head>

<body>

	<h1>Simple Database App</h1>