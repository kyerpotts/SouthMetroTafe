<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Party Cake Parlour - YOUR NAME</title>

	<link rel="stylesheet" href="css/style.css">
</head>

<body>

	<div class="container">
		<header></header>
		<nav>
			<!--create a bulleted list for the links for the website-->
			<ul>
				<li><a href="Index.php">Home</a><li>
				<li><a href="Suppliers.php">Suppliers</a><li>
				<li><a href="Products.php">Products</a><li>
				<li><a href="Invoices.php">Invoices</a><li>
				<li><a href="Customers.php">Customers</a><li>
			
			</ul>
		</nav>
		<main>