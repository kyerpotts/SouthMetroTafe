<?php
	// get the head of the html page
	include "templates/head.php"; 
	
	/* This page should contain a way of showing invoices.
	** You could have a form with a drop down box showing all Invoice Numbers. 
	** When selected it would show all details of that invoice
	*/
	

	include "templates/foot.php"; 
?>