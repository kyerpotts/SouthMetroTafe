<?php
	// get the head of the html page
	//ensure that you include your namein the title
	include "./templates/head.php"; 
		
	/* This page should contain a drop down box that displays all
	** suppliers.
	** Once submitted it should show all of the products from the supplier.
	** Make sure you display which category (i.e. Category Description)
	*/
?>
	<h1>Products by Supplier</h1>

<?php

		
	include "./templates/foot.php"; 
?>
