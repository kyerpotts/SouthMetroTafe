<?php
	// get the head of the html page
	//ensure that you include your namein the title
	
	/* This page should contain a drop down box that displays all
	** employees. When selected there should be a form that displays 
	** all information about that employee and is able to be updated
	*/
	
	include "./templates/head.php"; 
?>
	<h1>Employees</h1>

<?php
		
	include "./templates/foot.php"; 
?>
