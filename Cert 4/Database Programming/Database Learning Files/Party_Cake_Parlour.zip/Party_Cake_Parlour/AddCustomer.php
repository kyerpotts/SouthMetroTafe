<?php
	// get the head of the html page
	include "templates/head.php"; 
	
	/* This page should contain form that adds a new customer
	*/
	

	include "templates/foot.php"; 
?>