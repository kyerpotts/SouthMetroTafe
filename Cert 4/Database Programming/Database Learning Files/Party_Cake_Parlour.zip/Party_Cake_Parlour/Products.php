<?php
	// get the head of the html page
	//ensure that you include your namein the title
	include "./templates/head.php"; 
		
	/* This page should display all products.
	** There should also be options in the form of links to view 
	** products by Category or Supplier
	*/
?>
	<h1>Products</h1>

<?php

		
	include "./templates/foot.php"; 
?>
