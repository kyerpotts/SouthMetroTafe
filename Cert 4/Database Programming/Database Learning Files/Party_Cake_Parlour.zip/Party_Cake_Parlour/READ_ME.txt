Use the files as a starting point for Assessment 3.

You have been given some examples. See Suppliers.php (fully functional) and Customers.php (partially functional).
