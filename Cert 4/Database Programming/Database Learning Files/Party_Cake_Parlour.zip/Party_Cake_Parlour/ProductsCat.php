<?php
	// get the head of the html page
	//ensure that you include your namein the title
	include "./templates/head.php"; 
		
	/* This page should contain a drop down box that displays all
	** of the categories.
	** Once submitted it should show all of the products for a category.
	** Make sure you display which supplier (i.e. Supplier Name)
	*/
?>
	<h1>Products by Category</h1>

<?php

		
	include "./templates/foot.php"; 
?>
