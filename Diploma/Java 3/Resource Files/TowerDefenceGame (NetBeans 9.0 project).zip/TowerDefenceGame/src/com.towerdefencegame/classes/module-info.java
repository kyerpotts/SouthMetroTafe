module com.towerdefencegame {
    requires com.gameresources; // required module
}
