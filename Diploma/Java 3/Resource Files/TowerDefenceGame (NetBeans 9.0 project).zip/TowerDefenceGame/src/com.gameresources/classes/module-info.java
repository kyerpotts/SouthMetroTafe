module com.gameresources {
    exports com.gameresources; // exports a package
}
