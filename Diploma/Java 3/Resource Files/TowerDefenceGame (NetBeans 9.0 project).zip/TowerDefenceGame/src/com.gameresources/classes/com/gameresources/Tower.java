package com.gameresources;

public class Tower {
    public void attack(Enemy e, int attackStrengh) {
        e.getDamage(attackStrengh);
    }
}
