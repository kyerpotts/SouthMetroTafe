module com.fxmlapp {
    requires javafx.controls;
    requires javafx.fxml;
    
    exports com.fxmlapp;
}
